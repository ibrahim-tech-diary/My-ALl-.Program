# DOUBLY LINKED LIST
class Node:
    def __init__(self, data):
        self.data = data
        self.prev = None
        self.next = None


class DoublyLinkedList:
    def __init__(self):
        self.head = None
        self.tail = None

    def insert_beginning(self, data):
        node = Node(data)
        if self.head is None:
            self.head = self.tail = node
        else:
            node.next = self.head
            self.head.prev = node
            self.head = node

    def insert_end(self, data):
        node = Node(data)
        if self.tail is None:
            self.head = self.tail = node
        else:
            node.prev = self.tail
            self.tail.next = node
            self.tail = node

    # Positions start at 1
    def insert_position(self, data, position):
        if position < 1:
            raise ValueError("Position must be >= 1")
        if position == 1:
            self.insert_beginning(data)
            return
        current = self.head
        for _ in range(position - 2):
            if current is None:
                raise IndexError("Position out of range")
            current = current.next
        if current is None:
            raise IndexError("Position out of range")
        if current is self.tail:
            self.insert_end(data)
            return
        node = Node(data)
        node.next, node.prev = current.next, current
        current.next.prev = node
        current.next = node

    def delete_beginning(self):
        if self.head is None:
            return None
        value = self.head.data
        if self.head is self.tail:
            self.head = self.tail = None
        else:
            self.head = self.head.next
            self.head.prev = None
        return value

    def delete_end(self):
        if self.tail is None:
            return None
        value = self.tail.data
        if self.head is self.tail:
            self.head = self.tail = None
        else:
            self.tail = self.tail.prev
            self.tail.next = None
        return value

    def delete_position(self, position):
        if position < 1:
            raise ValueError("Position must be >= 1")
        if self.head is None:
            return None
        if position == 1:
            return self.delete_beginning()
        current = self.head
        for _ in range(position - 1):
            current = current.next
            if current is None:
                return None
        if current is self.tail:
            return self.delete_end()
        current.prev.next = current.next
        current.next.prev = current.prev
        return current.data

    def search(self, value):
        current, position = self.head, 1
        while current:
            if current.data == value:
                return position
            current, position = current.next, position + 1
        return -1

    def count(self):
        total, current = 0, self.head
        while current:
            total += 1
            current = current.next
        return total

    def display_forward(self):
        current = self.head
        while current:
            print(current.data, end=" <-> ")
            current = current.next
        print("None")

    def display_backward(self):
        current = self.tail
        while current:
            print(current.data, end=" <-> ")
            current = current.prev
        print("None")

    def reverse(self):
        current = self.head
        while current:
            current.prev, current.next = current.next, current.prev
            current = current.prev
        self.head, self.tail = self.tail, self.head


if __name__ == "__main__":
    dll = DoublyLinkedList()
    dll.insert_beginning(20); dll.insert_beginning(10)
    dll.insert_end(40); dll.insert_position(30, 3)
    print("Forward:"); dll.display_forward()
    print("Backward:"); dll.display_backward()
    print("Search 30:", dll.search(30))
    print("Count:", dll.count())
    dll.delete_position(3); dll.delete_beginning(); dll.delete_end()
    dll.display_forward()
    dll.insert_end(50); dll.insert_end(60)
    dll.reverse()
    dll.display_forward(); dll.display_backward()
