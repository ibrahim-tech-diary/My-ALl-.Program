# QUEUE
class Queue:
    def __init__(self):
        self.queue = []

    def enqueue(self, data):
        self.queue.append(data)

    def add(self, data):
        self.enqueue(data)

    def dequeue(self):
        return None if self.is_empty() else self.queue.pop(0)

    def remove(self):
        return self.dequeue()

    def front(self):
        return None if self.is_empty() else self.queue[0]

    def is_empty(self):
        return len(self.queue) == 0

    def size(self):
        return len(self.queue)

    def display(self):
        print(self.queue)


if __name__ == "__main__":
    q = Queue()
    q.enqueue(10); q.enqueue(20); q.add(30)
    q.display()
    print("Front:", q.front())
    print("Dequeue:", q.dequeue())
    print("Size:", q.size())
    print("Empty:", q.is_empty())
