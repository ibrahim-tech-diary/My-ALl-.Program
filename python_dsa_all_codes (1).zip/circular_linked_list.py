# CIRCULAR LINKED LIST (uses last pointer; head = last.next)
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class CircularLinkedList:
    def __init__(self):
        self.last = None

    def insert_beginning(self, data):
        node = Node(data)
        if self.last is None:
            node.next = node
            self.last = node
        else:
            node.next = self.last.next
            self.last.next = node

    def insert_end(self, data):
        self.insert_beginning(data)
        self.last = self.last.next

    # Positions start at 1
    def insert_position(self, data, position):
        if position < 1:
            raise ValueError("Position must be >= 1")
        if position == 1:
            self.insert_beginning(data)
            return
        if self.last is None:
            raise IndexError("Position out of range")
        current = self.last.next
        index = 1
        while index < position - 1 and current is not self.last:
            current = current.next
            index += 1
        if index != position - 1:
            raise IndexError("Position out of range")
        node = Node(data)
        node.next = current.next
        current.next = node
        if current is self.last:
            self.last = node

    def delete_beginning(self):
        if self.last is None:
            return None
        head = self.last.next
        value = head.data
        if head is self.last:
            self.last = None
        else:
            self.last.next = head.next
        return value

    def delete_end(self):
        if self.last is None:
            return None
        if self.last.next is self.last:
            return self.delete_beginning()
        current = self.last.next
        while current.next is not self.last:
            current = current.next
        value = self.last.data
        current.next = self.last.next
        self.last = current
        return value

    def delete_value(self, value):
        if self.last is None:
            return False
        previous, current = self.last, self.last.next
        while True:
            if current.data == value:
                if current is self.last and current.next is current:
                    self.last = None
                else:
                    previous.next = current.next
                    if current is self.last:
                        self.last = previous
                return True
            previous, current = current, current.next
            if current is self.last.next:
                return False

    def search(self, value):
        if self.last is None:
            return -1
        current, position = self.last.next, 1
        while True:
            if current.data == value:
                return position
            current, position = current.next, position + 1
            if current is self.last.next:
                return -1

    def count(self):
        if self.last is None:
            return 0
        total, current = 0, self.last.next
        while True:
            total += 1
            current = current.next
            if current is self.last.next:
                return total

    def reverse(self):
        if self.last is None or self.last.next is self.last:
            return
        head, previous, current = self.last.next, self.last, self.last.next
        while True:
            next_node = current.next
            current.next = previous
            previous, current = current, next_node
            if current is head:
                break
        self.last = head

    def display(self):
        if self.last is None:
            print("Empty")
            return
        head, current = self.last.next, self.last.next
        while True:
            print(current.data, end=" -> ")
            current = current.next
            if current is head:
                break
        print("(back to head)")

    def split_into_two(self):
        values = []
        if self.last:
            current = self.last.next
            while True:
                values.append(current.data)
                current = current.next
                if current is self.last.next:
                    break
        first, second = CircularLinkedList(), CircularLinkedList()
        middle = (len(values) + 1) // 2
        for value in values[:middle]:
            first.insert_end(value)
        for value in values[middle:]:
            second.insert_end(value)
        return first, second

    def josephus(self, k):
        if self.last is None or k < 1:
            return None
        current, previous = self.last.next, self.last
        while current.next is not current:
            for _ in range(k - 1):
                previous, current = current, current.next
            previous.next = current.next
            if current is self.last:
                self.last = previous
            current = previous.next
        self.last = current
        current.next = current
        return current.data

    def has_cycle(self):
        # A circular list is expected to have a cycle if it is non-empty.
        if self.last is None:
            return False
        slow = fast = self.last.next
        while fast and fast.next:
            slow, fast = slow.next, fast.next.next
            if slow is fast:
                return True
        return False


if __name__ == "__main__":
    cll = CircularLinkedList()
    cll.insert_end(10); cll.insert_end(20)
    cll.insert_beginning(5); cll.insert_position(15, 3)
    cll.display()
    print("Count:", cll.count(), "Search 15:", cll.search(15))
    cll.delete_value(15); cll.delete_beginning()
    cll.display()
    first, second = cll.split_into_two()
    print("First half:"); first.display()
    print("Second half:"); second.display()
    game = CircularLinkedList()
    for n in [1, 2, 3, 4, 5, 6, 7]:
        game.insert_end(n)
    print("Josephus survivor k=3:", game.josephus(3))
