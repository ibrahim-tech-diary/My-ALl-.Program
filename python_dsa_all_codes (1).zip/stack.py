# STACK
class Stack:
    def __init__(self):
        self.stack = []

    def push(self, data):
        self.stack.append(data)

    def pop(self):
        return None if self.is_empty() else self.stack.pop()

    def peek(self):
        return None if self.is_empty() else self.stack[-1]

    def is_empty(self):
        return len(self.stack) == 0

    def display(self):
        print(self.stack)


def is_valid_parentheses(text):
    stack = []
    pairs = {")": "(", "]": "[", "}": "{"}
    for char in text:
        if char in "([{":
            stack.append(char)
        elif char in ")]}":
            if not stack or stack.pop() != pairs[char]:
                return False
    return not stack


if __name__ == "__main__":
    s = Stack()
    s.push(10); s.push(20); s.push(30)
    s.display()
    print("Peek:", s.peek())
    print("Pop:", s.pop())
    print("Empty:", s.is_empty())
    print("Valid parentheses:", is_valid_parentheses("{[()]}"))
