Python DSA - All Codes

Files:
1. stack.py
2. queue.py
3. singly_linked_list.py
4. circular_linked_list.py
5. doubly_linked_list.py

Run any file:
python filename.py

Linked-list positions are 1-based.
Empty pop/dequeue/delete operations return None where appropriate.
Circular Linked List uses a last pointer; head is last.next.
