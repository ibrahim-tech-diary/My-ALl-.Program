# SINGLY / LINEAR LINKED LIST
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None


class LinkedList:
    def __init__(self):
        self.head = None

    def insert_beginning(self, data):
        node = Node(data)
        node.next = self.head
        self.head = node

    def insert_end(self, data):
        node = Node(data)
        if not self.head:
            self.head = node
            return
        current = self.head
        while current.next:
            current = current.next
        current.next = node

    # Positions start at 1
    def insert_position(self, data, position):
        if position < 1:
            raise ValueError("Position must be >= 1")
        if position == 1:
            self.insert_beginning(data)
            return
        current = self.head
        for _ in range(position - 2):
            if current is None:
                raise IndexError("Position out of range")
            current = current.next
        if current is None:
            raise IndexError("Position out of range")
        node = Node(data)
        node.next = current.next
        current.next = node

    def delete_beginning(self):
        if not self.head:
            return None
        value = self.head.data
        self.head = self.head.next
        return value

    def delete_end(self):
        if not self.head:
            return None
        if not self.head.next:
            return self.delete_beginning()
        current = self.head
        while current.next.next:
            current = current.next
        value = current.next.data
        current.next = None
        return value

    def delete_value(self, value):
        if not self.head:
            return False
        if self.head.data == value:
            self.head = self.head.next
            return True
        current = self.head
        while current.next and current.next.data != value:
            current = current.next
        if not current.next:
            return False
        current.next = current.next.next
        return True

    def delete_position(self, position):
        if position < 1:
            raise ValueError("Position must be >= 1")
        if not self.head:
            return None
        if position == 1:
            return self.delete_beginning()
        current = self.head
        for _ in range(position - 2):
            if current.next is None:
                return None
            current = current.next
        if current.next is None:
            return None
        value = current.next.data
        current.next = current.next.next
        return value

    def search(self, value):
        current, position = self.head, 1
        while current:
            if current.data == value:
                return position
            current, position = current.next, position + 1
        return -1

    def count(self):
        total, current = 0, self.head
        while current:
            total += 1
            current = current.next
        return total

    def reverse(self):
        previous, current = None, self.head
        while current:
            next_node = current.next
            current.next = previous
            previous, current = current, next_node
        self.head = previous

    def middle(self):
        slow = fast = self.head
        while fast and fast.next:
            slow, fast = slow.next, fast.next.next
        return None if slow is None else slow.data

    def has_cycle(self):
        slow = fast = self.head
        while fast and fast.next:
            slow, fast = slow.next, fast.next.next
            if slow is fast:
                return True
        return False

    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")


if __name__ == "__main__":
    ll = LinkedList()
    ll.insert_beginning(20); ll.insert_beginning(10)
    ll.insert_end(40); ll.insert_position(30, 3)
    ll.display()
    print("Search 30:", ll.search(30))
    print("Count:", ll.count())
    print("Middle:", ll.middle())
    print("Cycle:", ll.has_cycle())
    ll.delete_value(30); ll.delete_end()
    ll.display()
    ll.reverse(); ll.display()
